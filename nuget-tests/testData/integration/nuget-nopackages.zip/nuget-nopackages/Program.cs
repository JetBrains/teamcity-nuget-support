﻿using Castle.Core;
using Castle.Windsor;

namespace ConsoleApplication1
{
  class Program
  {
    static void Main(string[] args)
    {
    }

    public void Foo(IServiceProviderEx ex)
    {
      optimizeMe(ex.GetService<IWindsorContainer>());
    }

    public void optimizeMe(IWindsorContainer wc)
    {
      wc.AddChildContainer(wc);
    }
  }
}
