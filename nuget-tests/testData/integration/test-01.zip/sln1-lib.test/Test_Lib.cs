﻿using NUnit.Framework;

namespace sln1_lib.test
{
  [TestFixture]
  public class Test_Lib
  {
    [Test]
    public void Test_LibAPI_Instance()
    {
      new SuperLibraryClassNuGet();
    }

    [Test]
    public void Test_LibAPI_Call()
    {
      new SuperLibraryClassNuGet().SuperActionWithNuGet();
    }
  }
}
