﻿using System;
using Ninject.Planning.Bindings;

namespace sln1_lib
{
  public class SuperLibraryClassNuGet
  {
    public void SuperActionWithNuGet()
    {
      Console.Out.WriteLine("NuGet package:" + GetType() + typeof(BindingBuilder<>));
    }
  }
}
