﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary2
{
  public class Class2
  {
    public static String Foo { get { return "AAA";  } }
  }
}
