﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary3
{
  public class Class3
  {
    public static string Foo { get { return "aaa"; } }
  }
}
