﻿using System;
using ClassLibrary2;
using Newtonsoft.Json;

namespace ClassLibrary1
{
  public class Class1
  {
    public static void Main(string[] args)
    {
      JsonWriter w = null;
      w.WriteComment("12312");
      Console.Out.WriteLine("Class2.Foo = {0}", Class2.Foo);
    }
  }
}
