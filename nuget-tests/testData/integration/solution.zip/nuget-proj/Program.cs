﻿using System;

namespace nuget_proj
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Out.WriteLine(ClassLibrary1.ClassLib1.FOO);
      Console.Out.WriteLine(ClassLibrary2.ClassLib2.FOO);
    }
  }
}
