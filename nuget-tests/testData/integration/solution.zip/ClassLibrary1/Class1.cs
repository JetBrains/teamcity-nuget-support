﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
  public class ClassLib1
  {
    public const string FOO = "AAA";
  }
}
