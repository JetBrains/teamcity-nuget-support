﻿Public Class ClassLib2
  Public Const FOO = "222"

End Class
