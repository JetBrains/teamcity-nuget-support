
This project is an example of using UriBuilder to enable HATEOAS through Link headers

System Requirements:
====================
- Maven 2.0.9 or higher

Building the project:
====================
1. In root directoy

mvn clean install

This will build a WAR and run it with embedded Jetty
