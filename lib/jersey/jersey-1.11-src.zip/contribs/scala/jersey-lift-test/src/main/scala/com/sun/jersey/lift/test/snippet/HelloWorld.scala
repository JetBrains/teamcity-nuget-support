package com.sun.jersey.lift.test.snippet

class HelloWorld {
  def howdy = <span>Welcome to Jersey and Lift! at {new _root_.java.util.Date}</span>
}

